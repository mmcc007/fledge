#!/usr/bin/env bash

# script to bundle all the CI/CD code for delivery via Fledge

tar cfzv fastlane.tar.gz fastlane android/fastlane ios/fastlane script Gemfile*
